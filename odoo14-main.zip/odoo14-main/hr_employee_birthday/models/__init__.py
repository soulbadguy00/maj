from . import res_company
from . import res_config_setting
from . import hr_employee