# -*- coding:utf-8 -*-

{
    "name" : "Notification des dates d'anniversaire",
    "version" : "2.0",
    "author" : "Rodolphe Agnero",
    'category': 'Localization',
    "website" : "http://www.rodolpheagnero.com",
    "depends" : [
        "base","hr_update", "notify_managment"
    ],
    "description": """
     """,
    "init_xml" : [],
    "demo_xml" : [],
    "data" : [
        'views/res_config_settings_views.xml',
        'views/hr_employee_view.xml',
    ],
    "installable": True
}

