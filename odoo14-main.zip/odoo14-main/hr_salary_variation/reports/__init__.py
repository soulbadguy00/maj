from . import hr_salary_variation_xlsx
from . import hr_salary_variation_by_rule_xlsx