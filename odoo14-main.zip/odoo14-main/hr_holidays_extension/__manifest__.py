# -*- coding:utf-8 -*-

{
    "name" : "Extension de congés",
    "version" : "1.0",
    "author" : "Rodolphe Agnero",
    'category': 'Localization',
    "website" : "www.Rodolphe Agnero.net",
    "depends" : ["base","hr_holidays"],
    "description": """
     """,
    "init_xml" : [],
    "demo_xml" : [],
    "update_xml" : [
        'data/data.xml',
        'views/hr_holidays_view.xml',
        'views/hr_employee_view.xml',
        #'wizards/hr_holidays_summary_department_views.xml',
    ],
    "data":[],
    "installable": True
}

