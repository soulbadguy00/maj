from . import hr_contract_model
__author__ = 'ropi'
