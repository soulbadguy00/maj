from . import res_company
from . import res_bank
from . import hr_contract_category
from . import hr_category_salaire
from . import hr_employee
from . import hrDepartement
from . import res_config_setting
