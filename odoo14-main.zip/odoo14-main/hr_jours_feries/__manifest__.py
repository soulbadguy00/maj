##############################################################################
#
# Copyright (c) 2012 Rodolphe Agnero - support.Rodolphe Agnero.net
# Author: Rodolphe Agnero
#
# Fichier du module hr_jours_feries
# ##############################################################################
{
    "name" : "Gestion des jours feriés",
    "version" : "1.0",
    "author" : "Rodolphe Agnero",
    "category" : "Human Resources",
    "website" : "www.Rodolphe Agnero.net",
    "depends" : ['hr'],
    "description": """
    """,
    "init_xml" : [],
    "demo_xml" : [],
    "data": [
        "security/ir.model.access.csv",
        "views/hr_view.xml",
    ],
    "installable": True
}
