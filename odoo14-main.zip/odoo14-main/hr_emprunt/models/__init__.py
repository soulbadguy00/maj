from . import quotite_cessible
from . import hr_loaning
from . import hr_advance_salary
from . import hr_employee
