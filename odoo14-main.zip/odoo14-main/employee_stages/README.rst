EMPLOYEE STAGES
===============
Manage different stages of an employee.

Configuration
=============

No additional configurations needed

Credits
=======
Developer: V13 Varsha Vivek K @ cybrosys, Contact: odoo@cybrosys.com
           V14 Minhaj T @ cybrosys, Contact: odoo@cybrosys.com
